package Hanoisinpila;

public class DiscodePiedra extends Disco{

	public DiscodePiedra(int diametro) {
		super(diametro);
		
	}
	public void dibujarDisco(){
		String disco="";
		for(int i=0;i<this.diametroDisco();i++){
			disco=disco+"@";
		}
		System.out.println(disco);
	}
	public void dibujarDisco(int numEspacios){
		String disco="";
		for(int i=0;i<numEspacios;i++){
			disco=disco+" ";
		}
		for(int c=0;c<this.diametroDisco();c++){
			disco=disco+"@";
		}
		System.out.println(disco);
	}

}

package hanoiconpila;
import java.util.Stack;


import java.util.Arrays;

public class Poste <T> {
	
	private Object datos[]=null;
	private int len= 0;
	
	//en el constructor se especifica la capacidad inicial
	
	public Poste(int capacidadInicial) {
		datos=new Object[capacidadInicial];
	}
	public void agregar(T elm) {
		insertar(elm,len);
	}
	
	//metodo que comprueba si la poste esta vacia
	
		public boolean esVacio() {
			if(datos==null||len==0) {
			return true;
			}else
			return false;
		}
	
	public void insertar(T elm, int i) {
		if(len==datos.length) {
			Object aux[]=datos;
			datos=new Object[datos.length*2];
			for(int j=0; j<len; j++) {
				datos[j]=aux[j];
			}
			aux=null;
		}
		for (int j=len-1;j>=i;j--) {
			datos[j+1]=datos[j];
		}
		datos[i]=elm;
		len++;
	}
	public int buscar(T elm) {
		int i=0;
		//mientras no me pase del tope y mientras no encuentre
		for(;i<len&&!datos[i].equals(elm);i++);
		
		//si no me pase entonces encontre, si no ... no encontre
		return i<len ? i :-1;
	}
	
	//insertarDisco:Si el poste est� vac�o, el m�todo devuelve �null�.
	
	@SuppressWarnings("unchecked")
	public Object eliminar(int i) {
		Object aux=datos[i];
		for (int j=i; j<len-1;j++) {
			datos[j]=datos[j+1];
		}
		len--;
		return aux;
	}
	
	@SuppressWarnings("unchecked")
	public T obtener(int i) {
		return (T)datos[i];
	}
	//indica cuantos elementos tiene la coleccion
	public int cantidad() {
		return len;
	}
	//la capacidad inicial 
	public int capacidadInicial;
	
	//instancio la coleccion que mantendra los datos de la pila
	private Poste<T> coll = new Poste<T>(capacidadInicial);
	
	
	//el metodo apilar recibe un parametro de tipo T
	//insertarDisco:
	public void apilar(T elm) {
		coll.insertar(elm,0);
	}
	//el metodo desapilar retorna un elemento de tipo T
	//extraerDisco:
	public T desapilar() {
		return (T) coll.eliminar(0); 

	}
	  /**
     * Metodo que devuelve el ultimo disco de la torre,Pero sin eliminarlo
     * @return Devuelve el disco del tope de la torre
     */
    public Disco peek(){
    return coll.peek();
     }
    //DIBUJAR POSTE
    public void dibujarPoste() {
   int diametro=2;
   	 int i=0;
   	 for ( i = 1; i <= diametro; i++) {
            System.out.print( "O" );
   	 }
   	 }
	}
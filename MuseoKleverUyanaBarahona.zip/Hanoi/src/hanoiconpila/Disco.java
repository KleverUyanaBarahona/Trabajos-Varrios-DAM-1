package hanoiconpila;

public class Disco{
	private int diametro;

	
	public Disco(int diametro){
		this.diametro=diametro;
	}
	public int getDiametro() {
		return diametro;
	}

	public void setDiametro(int diametro) {
		this.diametro=diametro;}
	
	public void comprobarMenor3(int diametro){
		String mensaje1="ADVERTENCIA: di�metro demasiado peque�o, se le asigna un "+3;
	
		if(diametro<3){
			System.out.println(mensaje1);
			this.diametro=3;
		}}
	public void comprobarPar(int diametro) {
		String mensaje2= "ADVERTENCIA: di�metro del disco inv�lido, se le asigna un "+(diametro+1);
		if (diametro%2==0) {
		System.out.println(mensaje2);
				this.diametro=diametro+1;
			}
			}
		
public void dibujar() {
	 int i=0;
	 for ( i = 1; i <= diametro; i++) {
         System.out.print( "O" );

	 }
}
}



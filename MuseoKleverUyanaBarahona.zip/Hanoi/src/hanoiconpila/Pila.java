package hanoiconpila;

public class Pila <T> {

	//la capacidad inicial la hardcodeamos en esta constante
	private static final int capacidadInicial=10;
	
	//instancio la coleccion que mantendra los datos de la pila
	private Poste<T> coll = new Poste<T>(capacidadInicial);
	
	
	//el metodo apilar recibe un parametro de tipo T
	public void apilar(T elm) {
		coll.insertar(elm,0);
	}
	//el metodo desapilar retorna un elemento de tipo T
	public T desapilar() {
		return (T) coll.eliminar(0); 

	}

}
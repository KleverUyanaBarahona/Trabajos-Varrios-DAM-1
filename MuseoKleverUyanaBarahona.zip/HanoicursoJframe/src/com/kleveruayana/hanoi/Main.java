package com.kleveruayana.hanoi;

/**
 * @author klever uyana
 */
public class Main {

    public static void main(String[] args) {
        GUI juego = new GUI();
        juego.setVisible(true);
    }

}

package com.islasfilipinas.programacion;

/**
 * Clase LLamasProvinciales hija de llamada
 * con atrubutos Coste y Franja
 * constructor con Switch -- case 
 * @author klever Uyana
 *
 */
public class LLamadasProvinciales extends LLamada {

private double coste=0;
private int franja;
/**
 * Constructor de llamadasprovinciales
 * @param nor origen
 * @param ndes destino
 * @param dur duracion
 * @param f Franja horaria con Switch Case 
 */
public LLamadasProvinciales(String nor,String ndes,int dur, int f){
super(nor,ndes,dur);
franja=f;
switch (franja){
case 1: coste=0.20;break;
case 2: coste=0.25;break;
case 3: coste=0.30;break;
}
}
public double costeLLamada(){
double costetotal=coste*super.getDuracion();
return costetotal;
}
}
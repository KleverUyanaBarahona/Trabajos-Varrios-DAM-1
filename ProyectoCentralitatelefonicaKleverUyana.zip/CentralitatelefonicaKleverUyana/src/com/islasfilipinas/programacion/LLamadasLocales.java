package com.islasfilipinas.programacion;


/**
 * Clase LLamadas Locales hija de LLamada
 * atributos coste
 * con super -- contructor
 * y un metodo para el coste llamada
 * @author klever Uyana
 *
 */
public class LLamadasLocales extends LLamada {

private double coste;
/**
 * Super -- constructor
 * stributos heredados de llamada
 * @param nor origen 
 * @param ndes destino
 * @param dur duracion 
 */
public LLamadasLocales(String nor,String ndes,int dur){
super(nor,ndes,dur);
coste=0.15;
}
/**
 * metodo
 * Coste llamada
 */
public double costeLLamada(){
double costetotal=coste*super.getDuracion();
return costetotal;
}

}

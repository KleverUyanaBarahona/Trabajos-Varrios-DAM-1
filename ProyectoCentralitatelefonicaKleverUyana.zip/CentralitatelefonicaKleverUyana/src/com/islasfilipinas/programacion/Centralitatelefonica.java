package com.islasfilipinas.programacion;
/**
 * Esta es la clase Centralita Telefonica
 * contiene los atributos en privado  
 * nLLamadas y costeTotal
 * dos metodos get , metodo Regristrallamda y un metodo que imprime por pantalla.
 * @author klever Uyana
 *
 */
public class Centralitatelefonica {

	 private int nLLamadas;
	 private double costeTotal;
	 
	 
	 public Centralitatelefonica(){
	  nLLamadas=0;
	  costeTotal=0;
	 }
	 
	 public int getNLLamadas(){
	  return nLLamadas;
	 }
	 
	 public double getCosteLLamadas(){
	  return costeTotal;
	 }
	
	 public void registraLLamada(LLamada llamada){
	  nLLamadas++;
	  costeTotal+=llamada.costeLLamada();
	 }
	 
	 public void printInforme (){
	  System.out.println("El n�mero total de llamadas que realizaste es "+nLLamadas+" \n  El coste total de la Factura es "+costeTotal);
	  
	 }
	}

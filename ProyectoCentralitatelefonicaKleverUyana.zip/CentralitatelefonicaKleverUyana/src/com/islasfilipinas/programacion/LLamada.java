package com.islasfilipinas.programacion;

/**
 * Esta es la clase Abstracta llamada
 * Contiene los atributos
 * Origen destino y Duracion
 * Y un metodo Abstracto
 * @author Klever Uyana
 * 
 */

public abstract class LLamada {

private String nOrigen;
private String nDestino;
private int duracion;

/**
 * Constructor de llamadas
 * @param nor origen de la llamada
 * @param ndes destino de la llamada
 * @param dur duracion de la misma
 */
public LLamada(String nor, String ndes, int dur) {
	// TODO Auto-generated constructor stub
	nOrigen=nor;
	nDestino=ndes;
	duracion=dur;
}
/**
 * 
 * @return Duracion de la llamada
 */
public int getDuracion(){
return duracion;
}
public abstract double costeLLamada();
}
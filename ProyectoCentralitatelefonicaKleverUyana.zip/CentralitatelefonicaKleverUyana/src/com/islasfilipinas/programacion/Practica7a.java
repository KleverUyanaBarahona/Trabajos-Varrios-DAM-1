package com.islasfilipinas.programacion;
/**
 * Prueba1
 * @author klever
 *
 */
public class Practica7a {

		 public static void main(String[] args) {
		  Centralitatelefonica centralitatelefonica=new Centralitatelefonica();
		  //llamadas locales
		  LLamadasLocales llamadalocal1=new LLamadasLocales("666156599","661516998",10);
		  LLamadasLocales llamadalocal2=new LLamadasLocales("665595159","615984126",10);
		  LLamadasLocales llamadalocal3=new LLamadasLocales("661561123","616551165",10);
		  LLamadasLocales llamadalocal4=new LLamadasLocales("665595159","615984126",10);
		  LLamadasLocales llamadalocal5=new LLamadasLocales("661561123","616551165",10);
		  //llamadas provinciales
		  LLamadasProvinciales llamadaprov1=new LLamadasProvinciales("156891591","151589596",3,1);
		  LLamadasProvinciales llamadaprov2=new LLamadasProvinciales("198915169","981595995",2,2);
		  LLamadasProvinciales llamadaprov3=new LLamadasProvinciales("915619599","898156599",5,3);
		  LLamadasProvinciales llamadaprov4=new LLamadasProvinciales("198915169","981595995",2,2);
		  LLamadasProvinciales llamadaprov5=new LLamadasProvinciales("915619599","898156599",5,3);
		  //llamada al metodo de la clase centralitatelefonica
		  centralitatelefonica.registraLLamada(llamadalocal1);
		  centralitatelefonica.registraLLamada(llamadaprov1);
		  centralitatelefonica.registraLLamada(llamadalocal2);
		  centralitatelefonica.registraLLamada(llamadaprov2);
		  centralitatelefonica.registraLLamada(llamadalocal3);
		  centralitatelefonica.registraLLamada(llamadaprov3);
		  centralitatelefonica.registraLLamada(llamadalocal4);
		  centralitatelefonica.registraLLamada(llamadaprov4);
		  centralitatelefonica.registraLLamada(llamadalocal5);
		  centralitatelefonica.registraLLamada(llamadaprov5);
		  //impresion por pantalla numero de llamadas y factura
		  centralitatelefonica.printInforme();
		 }
		}